<?php
/**
 * Do not put custom translations here. They will be deleted on Easy Digital Downloads updates.
 *
 * Keep custom EDD translations in /wp-content/languages/edd/
 */